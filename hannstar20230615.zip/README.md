# 1.在local端起專案
### `yarn start`
node 版本16.18.1
包管理工具使用npm跟yarn都可

# 2.打包專案
打包完的檔案會在下列路徑
dist/js/main.js
dist/css/main.css
須把打包完的檔案放在magento底下，
hannstar-magento/code/Hannstar/Frontend/view/frontend/web/css/main.css
hannstar-magento/code/Hannstar/Frontend/view/frontend/web/js/main.js
js放入規格 
define(["jquery"], function ($) {
    "use strict";
    return function hannstarScript(){
        //放入打包過後的js
    }
});
css整包更新
### `yarn prod`


# 3.圖片(/Image)、影片(/Video)放在S3
開發機:magentodev.hannstar.com
測試機:magentoqas.hannstar.com
正試機:magentoprd.hannstar.com
行銷單位放圖路徑為:\\tpfile01\Projects\數位平台會議\官網四大平台LandingImage


# 4.新增頁面至magento
頁面新增至打包入口檔案 hannstar-magento/src/entry/index.js
加入新的 id 至 pageMappingObj，對應到magento頁面所rander的dom物件


# 5.資料夾結構
page (頁面)
component (頁面所用元件)
template (共用元件組合)
services (API管理)
i18n (多語系)
entry (打包進入點)
hannstar-magento/public/index.html (local端進入點 可在這邊調整語系)


# 6.取得magento資料
利用全域變數取得magento相關資料(登入狀態、語系、userName、groupId)
/code/Hannstar/Frontend/view/frontend/templates/main.phtml


# 7.document360
以下頁面資料為D360
官網 - 瀚宇彩晶團隊 / 認證與肯定 / 投資人關係 / 企業永續
各平台訊息中心
客戶服務平台 - 技術諮詢
產品行銷平台 – 六大應用文章

依送給API的參數不同取得文章
多筆文章 method: "GetAllArticles"、site: "document360 site tag"
單筆文章 method: "GetArticle"、site: "document360 Article Id"

頁面關於表格在D360分別用###TablePC、###TableM兩種Tag來區分
每個表格都需要用###Block tag 包起來

PDF樣式可參考下列網址
https://magentodev.hannstar.com/tw/sustainability/report/view


# 8.algolia
相關文件(https://www.algolia.com/doc/)
不同搜尋區塊對應不同index name (語系需替換)

Page      msgento_tw_pages2
News      msgento_tw_news
FAQ       msgento_tw_faq
Support   msgento_tw_support


# 9.zdassets
客服聊天機器人第三方套件，需要依照magento語系切換


# 10.magento更新指令
php bin/magento setup:upgrade
sudo php bin/magento setup:static-content:deploy -f
sudo php bin/magento setup:di:compile