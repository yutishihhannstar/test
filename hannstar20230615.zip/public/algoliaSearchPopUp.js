document.addEventListener("DOMContentLoaded", function () {
  var searchIcon = document.querySelector(".searchIcon");
  var popupComponent = document.querySelector(".PopupComponent");

  searchIcon.addEventListener("click", function () {
    popupComponent.classList.toggle("show");
  });
});
