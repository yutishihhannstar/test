import React from "react";
import Layout from "../../component/layout/main";
import usePageData from "./pageData";
import "./css.scss";
import "./revision.css";
import TemplateLayout from "../../templates/TemplateLayout/main";

const AboutFamily: React.FC = () => {
  const pageName = "AboutFamily";
  const pageData = usePageData();

  return (
    <Layout>
      <div className="about-family-page">
        <div className={`${pageName}MainContainer`}>
          <TemplateLayout {...pageData} />
        </div>
      </div>
    </Layout>
  );
};

export default AboutFamily;