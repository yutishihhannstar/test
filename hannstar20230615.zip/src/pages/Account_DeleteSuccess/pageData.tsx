import { useTranslation } from "react-i18next";
import { I_PageType } from "./interface";

function usePageData() {
  const { t } = useTranslation();
  const PageType: I_PageType = {
    title: t('Account_Logout.DeleteSuccessTitle'),
    content: t('Account_Logout.DeleteSuccessContent'),
  };
  return PageType;
}

export default usePageData;
