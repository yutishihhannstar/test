export type I_PageType = {
    title: string,
    content: string,
}