import React from "react";
import Layout from "../../component/layout/main";
import TemplateLayout from "../../templates/TemplateLayout/main";
import usePageData from "./pageData";
import "./css.scss";
import "./revision.css";
import SlickComponent from "../../component/slickComponent/main";



const Index: React.FC = () => {
  const pageName = "Index";
  const pageData = usePageData();

  return (
    <Layout>
      <div className={`${pageName}MainContainer`}>
        <div className="main-page-wrapper">
          <TemplateLayout {...pageData} />
          {/* <SlickComponent imgs={[]} /> */}
        </div>
      </div>
    </Layout>
  );
};

export default Index;
