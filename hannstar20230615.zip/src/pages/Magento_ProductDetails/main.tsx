import React, { useRef, useEffect, useState } from "react";
import Layout from "../../component/layout/main";
import Columns from "../../component/columns/main";
import { ColType } from "../../component/columns/interface";
import SlickComponent from "../../component/slickComponent/main";
import ModelViewer from "../../component/modelViewer/main";
import { urlConfig } from "../../config/urlSetting";

import usePageData from "./pageData";
import "./css.scss";

declare global {
  interface Window {
    hannstarProductImgs: any;
  }
}

const MagentoProductDetails: React.FC = () => {
  const pageName = "MagentoProductDetails";

  const pageData = usePageData();

  const magentoInfoBlock: any = useRef();
  const magentoDetailsBlock: any = useRef();

  useEffect(() => {
    const magentoInfoBlockDom: any =
      document.getElementsByClassName("product-info-main")[0];

    if (magentoInfoBlockDom)
      magentoInfoBlock.current.appendChild(magentoInfoBlockDom);
    const magentoDetailsBlockDom: any = document.getElementsByClassName(
      "product info detailed"
    )[0];

    if (magentoDetailsBlockDom)
      magentoDetailsBlock.current.appendChild(magentoDetailsBlockDom);
  }, []);

  return (
    <Layout>
      <div className={`${pageName}MainContainer`}>
        <Columns
          type={ColType.OneCol}
          content={
            <>
              <div className={`${pageName}Content`}>
                <div className="topBlock">
                  <div className="magentoProductMedia">
                    {/* <SlickComponent imgs={window.hannstarProductImgs} /> */}
                    <ModelViewer 
                      // src="https://modelviewer.dev/shared-assets/models/NeilArmstrong.glb"
                      src={`${urlConfig().s3Url}/Model/7.8LCM_20230316.glb`}
                    />
                    {/* <div className="sketchfab-embed-wrapper"> 
                      <iframe title="Tablet" 
                        frameBorder="0" 
                        allowFullScreen 
                        allow="autoplay; fullscreen; xr-spatial-tracking" 
                        xr-spatial-tracking 
                        execution-while-out-of-viewport 
                        execution-while-not-rendered 
                        web-share 
                        src="https://sketchfab.com/models/603e1036ffd444e583e52474c86fd2f9/embed?camera=0"
                      > 
                      </iframe> 
                    </div> */}
                  </div>
                  <div className="magentoInfo" ref={magentoInfoBlock}></div>
                </div>
                <div
                  className="magentoProductDetail"
                  ref={magentoDetailsBlock}
                ></div>
              </div>
            </>
          }
        />
      </div>
    </Layout>
  );
};

export default MagentoProductDetails;
