import { urlConfig } from "../../../config/urlSetting"

export const SolutionSmartRetailing = {
  bannerTitle: `智慧零售 數位生活`,
  bannerContent:`瀚宇彩晶基於IoT、AI和大數據分析為客戶提供全方面的智慧零售解決方案。透過電子標籤、直立式廣告螢幕、手持POS機和動態二維碼付款機等一系列應用，幫助零售商與品牌商打造”顧客、商品、場所”三位一體的關係，提升店家整體經營管理效率。`,
  title1:"智慧零售系統、設備",
  subTitle1:`智慧零售方案包括POS管理、ESL管理、數位內容管理...等系統，並能與公司ERP、WNS系統進行整合。`,
  cardTitle_1:"智慧POS系統",
  cardContent_1:`提供完整訂位、點餐、外帶、廚房出餐、多元支付、外送服務...等服務功能`,
  cardTitle_2:"智慧商店系統",
  cardContent_2:`智慧商店包含電子數位架籤、智能販售機、智能KIOSK、智慧結帳...等方案`,
  cardTitle_3:"數位內容管理",
  cardContent_3:`數位內容管理可應用於雲數位看板、雲音訊公播、商場導視、人流密度大型商業空間管理...`,
  cardTitle_4:"解決方案諮詢",
  cardContent_4:`除既有解決方案外，亦提供其他智慧零售相關場域之方案諮詢`,
  cardBtn_1:`了解更多資訊`,
  cardBtn_2:`與我們聯繫`,
  breadcrumbsItem:"首頁",
  breadcrumbsItem1:"方案整合及系統服務",
  breadcrumbsItem2:"智慧零售",
  bannerImg1:`${urlConfig().s3Url}/Image/solution/SmartSolution/SmartRetail/SmartRetailSystem&Equipment.png`,
}