export const Investors_Shareholdermeeting = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "股東會資訊",
};