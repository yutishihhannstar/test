import { urlConfig } from "../../../config/urlSetting";

export const About_Policy = {
  bannerText:"质量管理与策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"关于瀚宇彩晶",
  breadcrumbText3:"绿色产品政策",
  TitleContentBlock1:"绿色产品政策",
  TitleContentBlock2:" 为善尽绿色产品管理责任，瀚宇彩晶制定了绿色产品政策。除了设计更符合用户需求产品外，更期望在产品生命周期中能做到无毒性、省资源，且对环境无害的产品。秉持着取之社会、用之社会，为地球环境尽一分心力。",
  TitleContentBlock3:"绿色产品目标",
  TitleContentBlock4:"客户抱怨件数: 0件",
  TitleContentBlock5:"满足客户需求为最大宗旨及目标，偕同客户一起努力爱护地球。",
  TitleContentBlock6:"新产品符合绿色要求检测比例: 100%",
  TitleContentBlock7:"新产品开发，除设计开始选用合格供货商及材料外，并在验证最终阶段将产品送具ISO 17025合格实验室，以均质方式进行拆解并进行有害物质分析。以确保产品符合性。",
  TitleContentBlock8:"国际环保法规符合要求: 100%",
  TitleContentBlock9:"为了全体人类健康及环境着想，有关有害物质的国际法规限制也日趋严谨，瀚宇彩晶将持续对材料把关、并要求供货商提供相关合格检测报告，以期符合重要国际法规要求。",
  TitleContentBlock10:"无卤要求: 800ppm",
  TitleContentBlock11:"为落实 RoHS 2.0 要求，对于无卤物质规范重视也不遗余力，对于氯、溴含量标准要求<800ppm 以内，超前领先业界，更突显瀚宇彩晶满足绿色产品要求的决心。",
  GraphicsTitle1:"有害物质管控清单",
  GraphicsContent1:"依据国际法规及客户规范订【瀚宇彩晶环保规范】，除定期依需求更新外，并要求所属供货商符合，达到上、下游一致性整合。 目前禁用管制物质合计约近177项(2021年166项)",
  banner1:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_target_sc.png`,
  banner2:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_controllist_sc.png`,
};
