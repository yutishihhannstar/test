export const MFA = {
    formTitle: "请输入身份验证应用程式上的代码",
    errorMessage: "必填栏位。输入格式有误，请重新输入。",
    placeholder: "请输入代码",
    sendBtn: "登入",
    otherMessage: "如果您双重身份验证(2FA)的装置遗失或出现问题 可使用原注册邮箱进行身份验证，",
    linkText: "发送验证邮件"
  };