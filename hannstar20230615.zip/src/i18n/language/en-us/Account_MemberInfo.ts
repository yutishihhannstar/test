export const Account_MemberInfo = {
    breadcrumbsLinkFrontPage: "Home Page",
    breadcrumbsLinkMemberCentre:"Member Center",
    breadcrumbsLinkMemberInfo: "Member Information",
    inputEmail: "Please type email",
    contentTitle: "Member Information",
    contentLabel: "Member Invitation",
    contentBtn: "+Invite", 
    contentTableName: "Name", 
    contentTableEmail: "Email",
    contentTableJobTitle: "Job Title", 
};