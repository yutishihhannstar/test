export const ServiceIndex = {
  FullBannerTitle: "Customer Service",
  FullBannerText:
    "As a customer service platform, We are here to solve problems happened in various stages.  Our support team will take actions asap via our platform,  to make sure you are satisfied and create a win-win future together.",
  platform1: "Customer Support",
  platform2: "Green Eco",
  platform3: "Technical Support",
  title: "Customer Service",
  content:
    "As a customer service platform, We are here to solve problems happened in various stages.  Our support team will take actions asap via our platform,  to make sure you are satisfied and create a win-win future together.",
  GraphicsCardTitle1: "Support",
  GraphicsCardText1:
    "Customer Support Simple and convenient service, enjoy faster professional consultation and communication. A full-service team will work for you.",
  GraphicsCardTitle2: "Green ECO",
  GraphicsCardText2:
    "「Recycle、 Reuse、Reduce」 Promote green products. Obtained an environmental label. Meet the sustainable development.",
  GraphicsCardTitle3: "Technical Support",
  GraphicsCardText3:
    "Share technical experience and education training through the cloud， Even wecan't face-to-face, also can obtain knowledge from here.",
  BtnText: "More",
  ArticleListContentTitle1: "最新文章列表",
  catalog1: "技術文件",
  catalog2: "教育訓練",
};
