export const About_Event = {
  bannerText:"Quality Management Strategy",
  breadcrumbText1:"Home",
  breadcrumbText2:"About us",
  breadcrumbText3:"Green Product Events",
};
