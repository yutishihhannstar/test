export const About_Environmental = {
  bannerText:"Quality Management Strategy",
  breadcrumbText1:"Home",
  breadcrumbText2:"About us",
  breadcrumbText3:"Green Environment",
};
