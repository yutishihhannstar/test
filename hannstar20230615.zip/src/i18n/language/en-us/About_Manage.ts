export const About_Manage = {
  bannerText:"Quality Management Strategy",
  breadcrumbText1:"Home",
  breadcrumbText2:"About us",
  breadcrumbText3:"Quality Management Strategy",
};
