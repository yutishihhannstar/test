export const About_Team = {
  breadcrumbsItem1: "Home",
  breadcrumbsItem2: "About us",
  breadcrumbsItem3: "Management",
};
