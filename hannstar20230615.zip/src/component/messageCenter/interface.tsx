export interface I_GroupArray {
  tag: string;
  date: string;
  title: string;
}
