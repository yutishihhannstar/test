import React, { useState, useEffect, useRef } from "react";
import "./css.scss";
import { I_GroupArray } from "./interface";
import { postGetD360Art } from "../../services/api.service";
import mappingD360I18n from "../../common/mappingD360I18n";
import Loading from "../loading/main";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { urlConfig } from "../../config/urlSetting";
import { useTranslation } from "react-i18next";

const MessageCenter: React.FC = () => {
  const [d360Data, setD360Data] = useState<any>();
  const { t } = useTranslation();

  useEffect(() => {
    const postData = {
      method: "GetAllArticles",
      language: mappingD360I18n(window.hannstar?.language),
      site: "/news/esg",
    };

    postGetD360Art(postData).then((response: any) => {
      if (response.result === "success") {
        setD360Data(response.data);
      }
    });
  }, []);

  const sliderRef = useRef<any>(null);

  const groupArrByValue = (array: I_GroupArray[], subGroupLength: number) => {
    let index = 0;
    const newArray = [];
    while (index < array.length) {
      newArray.push({ data: array.slice(index, (index += subGroupLength)) });
    }
    return newArray;
  };

  const settings = {
    dots: false,
    arrows: false,
    fade: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const next = () => {
    sliderRef.current.slickNext();
  };
  const previous = () => {
    sliderRef.current.slickPrev();
  };

  return (
    <div className="messageCenter">
      <div className="leftBlock">
        <div className="toolBar">
          <div className="title">{`${t('Index.MessageCenterTitle')}`}</div>
          <div className="btnBlock">
            <div className="sliderBtn next" onClick={next}></div>
            <div className="sliderBtn previous" onClick={previous}></div>
          </div>
        </div>
        <a
          className="moreBtn"
          href={urlConfig().hannstar.news_esg.href}
        >
          MORE
        </a>
      </div>
      <div className="rightBlock">
        <Slider ref={sliderRef} {...settings}>
          {d360Data ? (
            groupArrByValue(d360Data, 3).map((item, idx) => (
              <div className="messageBlock" key={idx}>
                {item.data.map((obj, idx) => {
                  return (
                    <li key={idx}>
                      <div className="tag">{obj.tag}</div>
                      <div className="date">{obj["published-date"]}</div>
                      <div className="title">{obj.title}</div>
                    </li>
                  );
                })}
              </div>
            ))
          ) : (
            <Loading height="140px" />
          )}
        </Slider>
      </div>
    </div>
  );
};

export default MessageCenter;
