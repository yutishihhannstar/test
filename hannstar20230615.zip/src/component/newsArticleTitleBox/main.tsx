import React from "react";
import { useIsMobile } from "../../hooks";
import { I_NewsArticleTitleBox } from "./interface";
import "./css.scss";

const NewsArticleTitleBox: React.FC<I_NewsArticleTitleBox> = ({
  title,
  date,
  tag,
}) => {
  const isMobile = useIsMobile();
  const splitDate = (date:any) => {
    const dateArr = date.replaceAll(".", "/").split("/");
    const year = dateArr[0];
    const month = dateArr[1];
    const day = dateArr[2];
    return {
      year,
      month,
      day,
    };
  };
  return (
    <div className="newsArticleTitleBox">
      <div className="tag">{tag}</div>
      <div className="title-box">
        <div className="newsDateBox">
          <div className="day">{splitDate(date).day}</div>
          <div className="ym">{splitDate(date).year}.{splitDate(date).month}</div>
        </div>
        <h1>{title}</h1>
      </div>
    </div>
  );
};

export default NewsArticleTitleBox;
