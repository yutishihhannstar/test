export interface I_ModelViewer {
  src: string;
}
