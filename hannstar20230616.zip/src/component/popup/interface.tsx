export interface I_Popup {
    openFc: any
    content: JSX.Element
}