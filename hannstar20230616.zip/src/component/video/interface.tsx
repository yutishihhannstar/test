export interface I_Video {
    src: string;
}