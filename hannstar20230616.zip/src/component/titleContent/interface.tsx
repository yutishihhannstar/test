export interface I_TitleContent {
    title: string;
    content: string;
    btnText?: string;
    btnHref?: string;
    bgColor?: string;
}