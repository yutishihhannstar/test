export const Account_Dashboard = {
    breadcrumbsLinkFrontPage: "Home Page",
    breadcrumbsLinkMemberCentre:"Member Center",
    breadcrumbsLinkDashboard: "Dashboard",
    contentTitle: "Dashboard",
    contentTableDate: "Date",
    contentTableNumber: "NO.",
    contentTableProject: "Item",
    contentTableProductNo: "Model Name",
    contentTableSchedule: "Status",
    contentTableDetails: "Detail",
};