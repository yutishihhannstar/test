import { urlConfig } from "../../../config/urlSetting"

export const About_Certified = {
  bannerText:"Quality Management Strategy",
  breadcrumbText1:"Home",
  breadcrumbText2:"About us",
  breadcrumbText3:"Green Management and Certification",
  TitleContentTitle:"Green Management and Certification",
  TitleContent:`HannStar understand that the products provided by the company may have a significant impact on the environment. Therefore, in addition to focusing on user needs, functionality and added value in product design phase, HannStae make product design based on "reducing environmental load" perspective of thinking`,
  TitleContent2:`All suppliers are required to comply with the regulations, including energy saving, easy recycling, low toxicity, material labeling, packaging materials, etc.. Each supplier must provide a qualified product inspection report to prove that the product meets the requirements of the "HannStar Product Environmental Specifications", and submit it to the GP management unit for review before the component or product is recognized, and the GP management unit determines whether it is qualified to be used.`,
  TitleContent3:`Responding to EU RoHS 2.0 directive Since the announcement of the EU RoHS directive, HannStar has established a dedicated GP management unit, which collects and grasps relevant laws and related information of various countries, and conducts communication and advocacy with major component suppliers for each product line, regarding raw material examination, transition process and confirmation. After long-term efforts, all HannStar products have complied with the EU RoHS 2.0 directive.`,
  TitleContent4:`System Certification In addition to being committed to environmental protection, HannStar has also actively introduced various green product system certifications. Nanjing factory obtained IECQ QC080000 hazardous substance management system certification in March 2010. Tainan factory obtained SONY Green Partner certification in May 2019 and IECQ QC080000:2017 certification in December 2019. `,
  TitleContent5:`Green Product Management System In order to effectively manage qualified suppliers and materials, reduce the risk of hazardous substances. HannStar renewed its existing green product management system (GPM) in 2012, built supplier management information into it, and built a normative database and a substance database. In addition to more efficient management of the materials, it can also be used in the shortest time. Confirm the latest substances regulated by international laws and regulations, and product environmental protection regulations proposed by customers。`,
  BannerBlock1:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_mnc_eng.png`,
  TitleContent6:"Qualified material control",
  TitleContent7:"Suppliers of new product materials must complete the homogenization disassembly test report and upload the SDS data, and pass the review. It can become a qualified material, and the report is updated every year to maintain its effective status。",
  BannerBlock2:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_qc_eng.png`,
};
