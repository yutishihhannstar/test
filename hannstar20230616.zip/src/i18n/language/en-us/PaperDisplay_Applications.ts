import { urlConfig } from "../../../config/urlSetting";

export const PaperDisplay_Applications = {
    FullBannerTitle:"Paper Display Technology",
    BreadcrumbsBlock1:"Home",
    BreadcrumbsBlock2:"Paper Display Technology",
    ApplicationsTitle:"Applications",
    img1:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityEN.png`,
    imgHover1: `${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityhoverEN.png`,
    img2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmentEN.png`,
    imgHover2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmenthoverEN.png`,
    img3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailingEN.png`,
    imgHover3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailinghoverEW.png`,
    img4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcareEN.png`,
    imgHover4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcarehoverEN.png`,
    img5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoTEN.png`,
    imgHover5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoThoverEN.png`,
  };