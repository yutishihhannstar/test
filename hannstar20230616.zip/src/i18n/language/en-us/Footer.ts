export const Footer = {
  privacy:"Privacy Statement",
  legalnotices:"Legal Notice",
  siteMap:"Site map"
};
