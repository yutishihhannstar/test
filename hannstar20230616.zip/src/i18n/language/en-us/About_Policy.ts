import { urlConfig } from "../../../config/urlSetting";

export const About_Policy = {
  bannerText:"Quality Management Strategy",
  breadcrumbText1:"Home",
  breadcrumbText2:"About us",
  breadcrumbText3:"Green product policy",
  TitleContentBlock1:"Green product policy",
  TitleContentBlock2:"In order to fulfill the responsibility of green product management, HannStar has formulated a green product policy. In addition to designing products that are more in line with the needs of users, we also expect to be non-toxic, resource-saving, and environmentally friendly products in the product life cycle. Taken from society / Give back to society, and do a distraction for the earth's environment.",
  TitleContentBlock3:"Green Product Target",
  TitleContentBlock4:"Customer complaints: 0 piece",
  TitleContentBlock5:"Satisfying customer needs is the greatest purpose and goal, and work together with customers to care for the earth.",
  TitleContentBlock6:"New products meet green requirements: 100%",
  TitleContentBlock7:"In the development of new products, in addition to the selection of qualified suppliers and materials at the beginning of the design, the products are sent to ISO 17025 qualified laboratories in the final stage of verification, and the products are disassembled in a homogeneous manner and analyzed for hazardous substances. To ensure product compliance.",
  TitleContentBlock8:"International environmental protection regulations meet the requirements: 100%",
  TitleContentBlock9:"For the sake of human health and the environment, international regulations on hazardous substances are becoming more stringent. HannStar will continue to monitor materials and require suppliers to provide relevant qualified test reports in order to comply with important international regulations.",
  TitleContentBlock10:"Halogen-free : 800ppm",
  TitleContentBlock11:"To implement the RoHS 2.0 requirements, to pay attention to the standard of halogen-free substances, and to require less than 800ppm for chlorine and bromine content standards, leading the industry",
  GraphicsTitle1:"Hazardous Substance Control List",
  GraphicsContent1:`According to international regulations and customer specifications, the "Hannstar Environmental specification" is set, in addition to regular updates according to demand, and requires suppliers to comply with it to achieve consistent integration of upstream and downstream.Currently, there are about 177 prohibited substances in total.`,
  banner1:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_target_eng.png`,
  banner2:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_controllist_eng.png`,
};
