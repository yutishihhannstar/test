export const Footer = {
  privacy:"隱私權聲明",
  legalnotices:"法律聲明",
  siteMap:"網頁地圖"
};
