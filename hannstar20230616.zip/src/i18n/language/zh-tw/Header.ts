export const Header = {
  Login:"登入",
  Register:"註冊",
  MemberCenter:"會員中心",
  SignOut:"登出"
};