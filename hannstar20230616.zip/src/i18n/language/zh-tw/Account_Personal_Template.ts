export const Account_Personal_Template = {

    breadcrumbsLinkAccountInfo: "帳戶資訊",
    breadcrumbsLinkPersonal: "個人專區",
    breadcrumbsLinkAuthority:"權限管理",
    breadcrumbsLinkEnterprise:"企業專區",
    breadcrumbsLinkMember:"成員資訊",
    breadcrumbsLinkKanban:"看板",
}