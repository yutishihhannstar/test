export const About_Manage = {
  bannerText:"品質管理與策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"關於瀚宇彩晶",
  breadcrumbText3:"品質管理與策略",
};
