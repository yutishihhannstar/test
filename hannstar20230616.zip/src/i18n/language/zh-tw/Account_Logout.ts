export const Account_Logout = {
    title:"成功登出",
    content: "您已登出，將會在5秒內回到首頁",
    DeleteSuccessTitle:"您的帳號已刪除",
    DeleteSuccessContent: "5秒後將會到首頁。",
};