export const Account_Newsletter = {
    breadcrumbsLinkFrontPage: "首页",
    breadcrumbsLinkMemberCentre:"会员中心",
    breadcrumbsLinkNewsLetter: "订阅邮件",
    title: "订阅信件",
    subTitle: "信件类型",
    options: "行销与产品相关信件",
    saveBtn:"储存"
};