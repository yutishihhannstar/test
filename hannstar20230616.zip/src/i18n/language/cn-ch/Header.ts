export const Header = {
  Login:"登入",
  Register:"注册",
  MemberCenter:"会员中心",
  SignOut:"登出"
};