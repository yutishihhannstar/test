export const Investors_Revenue = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "每月營收",
};