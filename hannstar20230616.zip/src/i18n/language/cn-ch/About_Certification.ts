export const About_Certification = {
  breadcrumbsItem1: "首頁",
  breadcrumbsItem2: "关于瀚宇彩晶",
  breadcrumbsItem3: "认证与肯定",
};
