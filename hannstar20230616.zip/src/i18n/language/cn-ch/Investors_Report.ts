export const Investors_Report = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "財務季報及公司年報",
};