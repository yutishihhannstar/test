export const About_Manage = {
  bannerText:"质量管理与策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"关于瀚宇彩晶",
  breadcrumbText3:"质量管理与策略",
};
