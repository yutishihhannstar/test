export const Account_Logout = {
    title:"成功登出",
    content: "您已登出，将会在5秒内回到首页",
    DeleteSuccessTitle:"您的帐号已删除",
    DeleteSuccessContent: "5秒后将会到首页",
};