export const Investors_Summary = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "公司概況",
    breadcrumbsItem3: "公司概況2",
};