export const About_Team = {
  breadcrumbsItem1: "首頁",
  breadcrumbsItem2: "关于瀚宇彩晶",
  breadcrumbsItem3: "瀚宇彩晶团队",
};
