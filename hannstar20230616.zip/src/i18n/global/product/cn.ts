export const PRODUCT = {
  // 智能車載
  smartAutomotiveTitle: '智能车载应用',

  smartAutomotiveBct1:"首页",
  smartAutomotiveBct2:"产品资讯",
  smartAutomotiveBct3:"智能车载应用",
}