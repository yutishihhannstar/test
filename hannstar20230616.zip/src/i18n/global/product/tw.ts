export const PRODUCT = {
  // 智能車載
  smartAutomotiveTitle: '智能車載應用',

  smartAutomotiveBct1:"首頁",
  smartAutomotiveBct2:"產品資訊",
  smartAutomotiveBct3:"智能車載應用",
}