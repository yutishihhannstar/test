export const PRODUCT = {
  // 智能車載
  smartAutomotiveTitle: 'Smart Automotive Application',

  smartAutomotiveBct1:"Home",
  smartAutomotiveBct2:"PRODUCTS INFORMATION",
  smartAutomotiveBct3:"SMART AUTOMOTIVE APPLICATION",
}