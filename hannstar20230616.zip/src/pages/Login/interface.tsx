export interface I_PageData {
  loginTitle: string;
  account: string;
  password: string;
  rememberAccount: string;
  forgotPassword: string;
  createAccount: string;
  required: string;
  loginBtn: string;
  hasAccount: string;
  errorMessage: string;
  emailPlaceholder: string;
}
