import { useTranslation } from "react-i18next";
import { I_PageType } from "./interface";

function usePageData() {
    const { t } = useTranslation();
    const PageType: I_PageType = {
        breadcrumbs: {
            title: t('Investors_Contacts.breadcrumbsItem2'),
            breadcrumbsLink: [
                {
                    text: t('Investors_Contacts.breadcrumbsItem1'),
                    href: "/",
                },
                {
                    text: t('Investors_Contacts.breadcrumbsItem2'),
                    href: "",
                },
            ],
        }
    };

    return PageType;
}

export default usePageData;
