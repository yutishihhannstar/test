import { useTranslation } from "react-i18next";

function usePageData() {
  const { t } = useTranslation();
}

export default usePageData;
