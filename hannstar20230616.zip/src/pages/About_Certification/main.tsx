import React from "react";
import Layout from "../../component/layout/main";
import usePageData from "./pageData";
import Columns from "../../component/columns/main";
import Breadcrumbs from "../../component/breadcrumbs/main";
import { ColType } from "../../component/columns/interface";
import D360Templates from "../../templates/D360Templates/main";
import "./css.scss";
import "./revision.css";
import { useTranslation } from "react-i18next";
import { urlConfig } from "./../../config/urlSetting";

const AboutCertification: React.FC = () => {
  const pageName = "AboutCertification";
  const pageData = usePageData();
  const { t } = useTranslation();
  const D360TemplatesProp =
  {
    site: "37a234bc-7919-49db-bec6-7c2564d18453",
    method: "GetArticle"
  }

  return (
    <Layout>
      <div className="about-certificate-page">
        <div className="top-banner">
          <img src={`${urlConfig().s3Url}/Image/hannstar/about/Certificate/certificateTopBanner.png`} />
          <div className="textBlock bottomLeft main-banner-text">
            <h2 className="title">
              {t("About_Certification.breadcrumbsItem3")}
            </h2>
            <div className="text">
              <p></p>
            </div>
          </div>
        </div>
        <Columns
          type={ColType.OneCol}
          content={<Breadcrumbs {...pageData.breadcrumbs} />} />
        <D360Templates {...D360TemplatesProp} />
      </div>
    </Layout>
  );
};

export default AboutCertification;
