import { I_Breadcrumbs } from "../../component/breadcrumbs/interface";

export interface I_PageType {
    breadcrumbs: I_Breadcrumbs,
}